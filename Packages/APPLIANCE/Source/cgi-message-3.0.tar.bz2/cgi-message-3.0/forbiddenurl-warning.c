#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

char *url( void )
{
  static char url[URL_LEN];
  cgiFormStringNoNewlines( "url", url, URL_LEN );
  return url;
}

char *bl( void )
{
  static char bl[BL_LEN];
  cgiFormStringNoNewlines( "bl", bl, BL_LEN );
  return bl;
}

char *ip( void )
{
  static char ip[IP_LEN];
  cgiFormStringNoNewlines( "ip", ip, IP_LEN );

  // Remove the postfix "/-"
  char *str = strrchr( ip, '/');
  if (str != NULL) {
    *str = '\0';
  }

  return ip;
}

char *user( void )
{
  static char user[USER_LEN];
  cgiFormStringNoNewlines( "user", user, USER_LEN );

  if (strcmp( user, "" ) == 0)
    strcpy( user, "-" );

  return user;
}

char *emailBL( const char *url, const char *bl, const char *ip, const char *user )
{
  char email[EMAIL_LEN];
  static char mailto[MAILTO_LEN] = "<a href='mailto:";

  cgiFormStringNoNewlines( "email", email, EMAIL_LEN );
  char *email1 = strreplace( email, "(at)", "@" );

  strcat( mailto, email1 );
  strcat( mailto, "?subject=BL mistakes&body=URL: " );
  strcat( mailto, url );
  strcat( mailto, "%0ACategory: " );
  strcat( mailto, bl );
  strcat( mailto, "%0AIP: " );
  strcat( mailto, ip );
  strcat( mailto, "%0AUser: " );
  strcat( mailto, user );
  strcat( mailto, "'>" );

  strcat( mailto, email1 );
  strcat( mailto, "</a>" );
  
  return mailto;
}

int cgiMain( void )
{
  char *urlstr = url( );
  char *blstr = bl( );
  char *ipstr = ip( );
  char *userstr = user( );

  char *mailto = emailBL( urlstr, blstr, ipstr, userstr );

  beginPrintItem( "Access denied", "URL Blacklisted", "This content is not allowed", 1 );

  printMessage( "Your Web access provider has blocked this content at the gateway. If you think this is an error feel free to inform your provider at: ", mailto );

  printItem( "Requested URL<br />(without arguments)", urlstr );
  printItem( "Category", blstr );
  printItem( "Source IP", ipstr );
  printItem( "User", userstr );

  endPrintItem( );
  return 0;
}
