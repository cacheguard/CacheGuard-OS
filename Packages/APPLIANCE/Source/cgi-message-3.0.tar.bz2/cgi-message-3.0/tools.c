#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

char *printSignatureContent( char *signature, const char *file )
{
  FILE *fp = fopen( file, "r" );
  if (fp != NULL) {
    size_t len = fread( signature, sizeof(char), SIGNATURE_LEN, fp );
    if (len == 0) {
      strcpy( signature, "<i>Error 1: can't read the signature</i>" );
    }
    fclose(fp);
  }
  else {
      strcpy( signature, "<i>Error 1: can't open the signature file</i>" );
  }

 return signature;
}

char *email( const char *subject )
{
  char email[EMAIL_LEN];
  static char mailto[MAILTO_LEN] = "<a href='mailto:";

  cgiFormStringNoNewlines( "email", email, EMAIL_LEN );
  char *email1 = strreplace( email, "(at)", "@" );

  strcat( mailto, email1 );
  strcat( mailto, "?subject=" );
  strcat( mailto, subject );
  strcat( mailto, "'>" );

  strcat( mailto, email1 );
  strcat( mailto, "</a>" );
  
  return mailto;
}

char *binaryHref( char *href, const char *path, const char *name )
{
  strcpy( href, "<a href='" );
  strcat( href, path );
  strcat( href, "/" );
  strcat( href, name );
  strcat( href, "' download>" );
  strcat( href, name );
  strcat( href, "</a>" );
  
  return href;
}

char *asIsHref( char *href, const char *path, const char *name )
{
  strcpy( href, "<a href='" );
  strcat( href, path );
  strcat( href, "/" );
  strcat( href, name );
  strcat( href, "'>" );
  strcat( href, name );
  strcat( href, "</a>" );
  
  return href;
}

void printItem( char *attr, char *val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>%s</td>", attr );
  fprintf( cgiOut, "<td>" );
  cgiHtmlEscape( val );
  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void printMessage( char *val, char *opt_val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>Message</td>" );
  fprintf( cgiOut, "<td>" );
  cgiHtmlEscape( val );

  if (opt_val) {
    fprintf( cgiOut, "%s.",  opt_val );
  }

  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void printHTMLMessage( char *val, char *opt_val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td></td>" );
  fprintf( cgiOut, "<td>" );
  fprintf( cgiOut, "%s", val );

  if (opt_val) {
    fprintf( cgiOut, "%s.",  opt_val );
  }

  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void printHTMLItem( const char *attr, const char *val)
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>%s</td>", attr );
  fprintf( cgiOut, "<td>%s</td>", val );
  fprintf( cgiOut, "</tr>\n" );
}

void beginPrintItem( char *title1, char *title2, char *message, int stylein )
{
  cgiHeaderContentType( "text/html" );
  fprintf( cgiOut, "<!DOCTYPE html>\n" );
  fprintf( cgiOut, "<html>\n" );
  fprintf( cgiOut, "<head>\n" );
  fprintf( cgiOut, "<title>%s</title>\n", title1 );

  if (stylein) {
    char filename[32]="/www/";
    FILE *pfile;
    char line[ 128 ];
    strcat ( filename, STYLES_CSS );

    fprintf( cgiOut, "<style type='text/css'>\n" );

    if((pfile = fopen( filename, "r" )) != NULL) {
      while ( fgets ( line, sizeof line, pfile ) != NULL ) {
	fprintf( cgiOut, "%s", line );
      }
      fclose ( pfile );
    }

    fprintf( cgiOut, "</style>\n" );
  }
  else {
    fprintf( cgiOut, "<link rel='stylesheet' type='text/css' href='" );
    fprintf( cgiOut, "/%s' />\n", STYLES_CSS );
  }

  fprintf( cgiOut, "</head>\n" );
  fprintf( cgiOut, "<body>\n" );
  fprintf( cgiOut, "<div id='wrap'><div id='content'>\n" );
  fprintf( cgiOut, "<table>\n" );
  fprintf( cgiOut, "<tr>\n" );
  fprintf( cgiOut, "<td width='25%'><center>%s</center></td>", title2 );
  fprintf( cgiOut, "<td width='75%'><center>%s</center></td>", message );
  fprintf( cgiOut, "</tr>\n" );

}

void endPrintItem( void )
{
  fprintf( cgiOut, "</table>\n" );
  fprintf( cgiOut, "</div></div>\n" );
  fprintf( cgiOut, "</body>\n" );
  fprintf( cgiOut, "</html>\n" );
}

char *strreplace(char *str, char *orig, char *rep)
{
  static char buffer[512];
  char *p;

  if(!(p = strstr(str, orig)))
    return str;
  
  strncpy(buffer, str, p-str);
  buffer[p-str] = '\0';

  sprintf(buffer+(p-str), "%s%s", rep, p+strlen(orig));

  return buffer;
}

char *readFromMessageFile( void )
{
  FILE *file;
  static char message[MESSAGE_LENGTH];

  file = fopen( MESSAGE_FILE, "r" );

  if (file == NULL) {
    strcpy( message, "Something went wrong with your subscription." );
  }
  else {
    fgets( message, MESSAGE_LENGTH, file );
    message[strcspn( message, "\n" )] = 0;
    fclose( file );
  }
  return message;
}
