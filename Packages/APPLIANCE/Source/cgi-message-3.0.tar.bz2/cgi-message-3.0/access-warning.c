#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

int cgiMain( void )
{
  char *mailto = email( "Gateway Suspended" );
  char *message = readFromMessageFile( );

  beginPrintItem( "Access Suspended", "Access Suspended", "Your Web Gateway is suspended", 1 );
  strcat( message, "<p />Now all security and optimization services are down.<p />Feel free to contact a sales specialist for further information.<p />Email any requests to your administrator at: " );
  printHTMLMessage( message, mailto );
  endPrintItem( );
  return 0;
}
