#define MESSAGE_LEN 512
#define MAILTO_LEN 256+256+256+15+256+64
#define EMAIL_LEN 256
#define HREF_LEN 256
#define URL_LEN 512
#define BL_LEN 256
#define USER_LEN 256
#define VIRUS_LEN 256
#define IP_LEN 16
#define SIGNATURE_LEN 256

#define STYLES_CSS "styles.css"
#define CA_DIR "/ca"
#define CA_DER "ca.der"
#define CA_CRT "ca.crt"
#define SIG_CA_DER "/www/ca/ca.der.sha1"
#define SIG_CA_CRT "/www/ca/ca.crt.sha1"

#define MESSAGE_LENGTH 256

#ifndef MESSAGE_FILE
#define MESSAGE_FILE "/var/run/cgi-message"
#endif

char *email( const char * );
char *asIsHref( char *, const char *, const char * );
char *binaryHref( char *, const char *, const char * );
char *printSignatureContent( char *, const char * );

void printItem( char *, char * );
void printHTMLItem(const char *, const char *);
void beginPrintItem( char *, char *, char *, int );
void endPrintItem( );
char *strreplace(char *, char *, char *);
void printMessage( char *, char * );
void printHTMLMessage( char *, char * );
char *readFromMessageFile( void );
