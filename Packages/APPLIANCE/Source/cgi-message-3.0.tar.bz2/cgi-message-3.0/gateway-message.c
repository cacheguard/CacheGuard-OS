#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

int cgiMain( void )
{
  static char certificate_message[MESSAGE_LEN] = "";
  static char href[HREF_LEN];
  static char signature[SIGNATURE_LEN];

  beginPrintItem( "Secure Gateway", "Secure Gateway", "Secure Gateway", 0 );

  printHTMLMessage( "You can securely access the internet via this Gateway. In addition network traffic passing through this gateway can be optimized for better performances. Accessing the internet via this gateway may be restricted.<p>In case where the SSL mediation is activated on this gateway, encrypted traffic may be decrypted by this gateway in order to be inspected and/or cached. In this case, you should trust the CA certificate used to sign dynamically generated certificates used to re encrypt traffic (see below).", NULL );

  char *mailto = email(  "Gateway Message" );
  printHTMLMessage( "Email any requests to your gateway administrator at: ", mailto );

  char *certificate = asIsHref( href, CA_DIR, CA_DER );
  char *certificate_sha1 = printSignatureContent( signature, SIG_CA_DER );
  strcat( certificate_message,  "You can find the CA certificate of this Web Gateway in DER form at: " );
  strcat( certificate_message, certificate );
  strcat( certificate_message, " - <strong>CAUTION</strong>: always check the authenticity of a CA before any installation. The fingerprint of this CA is" );
  printHTMLMessage( certificate_message, certificate_sha1 );

  certificate = binaryHref( href, CA_DIR, CA_CRT );
  certificate_sha1 = printSignatureContent( signature, SIG_CA_CRT );
  strcpy( certificate_message, "" );
  strcat( certificate_message,  "You can find the CA of this Web Gateway in PEM form at: " );
  strcat( certificate_message, certificate );
  strcat( certificate_message, " - <strong>CAUTION</strong>: always check the authenticity of a CA before any installation. The fingerprint of this CA is" );
  printHTMLMessage( certificate_message, certificate_sha1 );

  endPrintItem( );
  return 0;
}
