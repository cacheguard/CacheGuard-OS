#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "cgic.h"
#include "tools.h"

void strreplace( char *str, const char *old, const char *newstr )
{
  char buffer[1024];
  char *p;

  while ((p = strstr(str, old)) != NULL) {
    buffer[0] = '\0';

    strncat( buffer, str, p - str );
    strcat( buffer, newstr );
    strcat( buffer, p + strlen( old ));

    strcpy( str, buffer );
  }
}

char *printSignatureContent( char *signature, const char *file )
{
  FILE *fp = fopen( file, "r" );
  if (fp != NULL) {
    size_t len = fread( signature, sizeof(char), SIGNATURE_LEN, fp );
    if (len == 0) {
      strcpy( signature, " (<font color='red'>error: can't read the signature</font>)" );
    }
    fclose(fp);
  }
  else {
      strcpy( signature, " (<font color='red'>error: can't open the signature file</font>)" );
  }

 return signature;
}

void decodeURL(char *src, char *dst)
{
  char a, b;

  while (*src) {
    if ((*src == '%') &&
	((a = src[1]) && (b = src[2])) &&
	(isxdigit(a) && isxdigit(b))) {
      if (a >= 'a') a -= 'a' - 'A';
      if (a >= 'A') a = a - 'A' + 10;
      else a -= '0';

      if (b >= 'a') b -= 'a' - 'A';
      if (b >= 'A') b = b - 'A' + 10;
      else b -= '0';

      *dst++ = 16 * a + b;
      src += 3;
    }
    else if (*src == '+') {
      *dst++ = ' ';
      src++;
    }
    else {
      *dst++ = *src++;
    }
  }

  *dst = '\0';
}

char *email( const char *subject )
{
  char email[EMAIL_LEN];
  char email_decoded[EMAIL_LEN];
  static char mailto[MAILTO_LEN] = "<a href='mailto:";

  cgiFormStringNoNewlines( "email", email, EMAIL_LEN );
  decodeURL( email, email_decoded );
  strreplace( email_decoded, "(at)", "@" );

  strcat( mailto, email_decoded );
  strcat( mailto, "?subject=" );
  strcat( mailto, subject );
  strcat( mailto, "'>" );

  strreplace( email_decoded, "<", "&lt;" );
  strreplace( email_decoded, ">", "&gt;" );

  strcat( mailto, email_decoded );
  strcat( mailto, "</a>" );
  
  return mailto;
}

char *binaryHref( char *href, const char *path, const char *name )
{
  strcpy( href, "<a href='" );
  strcat( href, path );
  strcat( href, "/" );
  strcat( href, name );
  strcat( href, "' download>" );
  strcat( href, name );
  strcat( href, "</a>" );
  
  return href;
}

char *asIsHref( char *href, const char *path, const char *name )
{
  strcpy( href, "<a href='" );
  strcat( href, path );
  strcat( href, "/" );
  strcat( href, name );
  strcat( href, "'>" );
  strcat( href, name );
  strcat( href, "</a>" );
  
  return href;
}

void printItem( char *attr, char *val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>%s</td>", attr );
  fprintf( cgiOut, "<td>" );
  cgiHtmlEscape( val );
  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void printMessage( char *val, char *opt_val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>Message</td>" );
  fprintf( cgiOut, "<td>" );
  cgiHtmlEscape( val );

  if (opt_val) {
    fprintf( cgiOut, "%s.", opt_val );
  }

  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void beginPrintMessage( char *title1, char *title2 )
{
  cgiHeaderContentType( "text/html; charset='utf-8'" );

  fprintf( cgiOut, "<!DOCTYPE html>\n" );
  fprintf( cgiOut, "<html>\n" );
  fprintf( cgiOut, "<head>\n" );
  fprintf( cgiOut, "<title>%s</title>\n", title1 );

  fprintf( cgiOut, "<link rel='stylesheet' type='text/css' href='/styles.css' />\n" );
  fprintf( cgiOut, "</head>\n" );
  fprintf( cgiOut, "<body>\n" );
  fprintf( cgiOut, "<div id='wrap'><div id='content'>\n" );
  fprintf( cgiOut, "<table>\n" );
  fprintf( cgiOut, "<tr><td>%s</td></tr>\n", title2 );
}

void endPrintMessage( void )
{
  fprintf( cgiOut, "</table>\n" );
  fprintf( cgiOut, "</div></div>\n" );
  fprintf( cgiOut, "</body>\n" );
  fprintf( cgiOut, "</html>\n" );
}

void printHTMLMessage( char *val, char *opt_val )
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>" );
  fprintf( cgiOut, "%s", val );

  if (opt_val) {
    fprintf( cgiOut, "%s.",  opt_val );
  }

  fprintf( cgiOut, "</td>" );
  fprintf( cgiOut, "</tr>\n" );
}

void printHTMLItem( const char *attr, const char *val)
{
  fprintf( cgiOut, "<tr>" );
  fprintf( cgiOut, "<td>%s</td>", attr );
  fprintf( cgiOut, "<td>%s</td>", val );
  fprintf( cgiOut, "</tr>\n" );
}

void beginPrintItem( char *title1, char *title2, char *message )
{
  cgiHeaderContentType( "text/html; charset='utf-8'" );

  fprintf( cgiOut, "<!DOCTYPE html>\n" );
  fprintf( cgiOut, "<html>\n" );
  fprintf( cgiOut, "<head>\n" );
  fprintf( cgiOut, "<title>%s</title>\n", title1 );

  fprintf( cgiOut, "<link rel='stylesheet' type='text/css' href='/styles.css' />\n" );
  fprintf( cgiOut, "</head>\n" );
  fprintf( cgiOut, "<body>\n" );
  fprintf( cgiOut, "<div id='wrap'><div id='content'>\n" );
  fprintf( cgiOut, "<table>\n" );
  fprintf( cgiOut, "<tr>\n" );
  fprintf( cgiOut, "<td>%s</td>", title2 );
  fprintf( cgiOut, "<td>%s</td>", message );
  fprintf( cgiOut, "</tr>\n" );
}

void endPrintItem( void )
{
  fprintf( cgiOut, "</table>\n" );
  fprintf( cgiOut, "</div></div>\n" );
  fprintf( cgiOut, "</body>\n" );
  fprintf( cgiOut, "</html>\n" );
}

char *readFromMessageFile( void )
{
  FILE *file;
  static char message[MESSAGE_LENGTH];

  file = fopen( MESSAGE_FILE, "r" );

  if (file == NULL) {
    strcpy( message, "There is a problem with your security gateway subscription." );
  }
  else {
    fgets( message, MESSAGE_LENGTH, file );
    message[strcspn( message, "\n" )] = 0;
    fclose( file );
  }
  return message;
}
