#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

int cgiMain( void )
{
  char *mailto = email( "Gateway Suspended" );
  char *message = readFromMessageFile( );

  beginPrintMessage( "Access Suspended", "Your Web Gateway is Suspended" );

  strcat( message, " All security and optimisation services are currently disabled. Please contact a sales representative for further information." );

  printHTMLMessage( message, NULL );
  printHTMLMessage( "Email any requests or inquiries to your gateway administrator at: ", mailto );

  endPrintMessage( );

  return 0;
}
