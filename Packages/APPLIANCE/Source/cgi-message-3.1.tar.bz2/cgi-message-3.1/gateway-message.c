#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include "tools.h"

int cgiMain( void )
{
  static char certificate_message[MESSAGE_LEN] = "";
  static char href[HREF_LEN];
  static char signature[SIGNATURE_LEN];
  char *certificate, *certificate_sha1;
  char *mailto = email( "Gateway Message" );

  beginPrintMessage( "Secure Gateway", "Secure Gateway" );

  printHTMLMessage( "You can securely access the Internet through this gateway. In addition, network traffic passing through this gateway may be optimised to improve performance. Access to the Internet through this gateway may be subject to restrictions. If SSL mediation is enabled on this gateway, encrypted traffic may be decrypted in order to be inspected and/or cached. In such cases, you should trust the CA certificate used to sign the dynamically generated certificates that are used to re-encrypt the traffic.", NULL );

  strcat( certificate_message, "You can download the CA certificate for this web gateway in DER and PEM formats at the following locations: " );
  certificate = asIsHref( href, CA_DIR, CA_DER );
  certificate_sha1 = printSignatureContent( signature, SIG_CA_DER );

  strcat( certificate_message, certificate );
  strcat( certificate_message, certificate_sha1 );
  strcat( certificate_message, ", " );

  certificate = binaryHref( href, CA_DIR, CA_CRT );
  certificate_sha1 = printSignatureContent( signature, SIG_CA_CRT );

  strcat( certificate_message, certificate );
  strcat( certificate_message, certificate_sha1 );
  strcat( certificate_message, ". <strong>CAUTION</strong>: Always verify the authenticity of a CA certificate before installing it." );

  printHTMLMessage( certificate_message, NULL );

  printHTMLMessage( "Email any requests or inquiries to your gateway administrator at: ", mailto );

  endPrintMessage( );

  return 0;
}
